function d = dist(a, b)
    d = sum((a - b).^2,2);
end